# HUD-Flashback par WayZe#0001

Bonjour à tous je vous présente aujourd'hui une petite modification du [esx_customui](https://github.com/ItsikNox/FiveM-Arkadia_/tree/master/resources/%5Bhud%5D/esx_customui) du même style que l'HUD du très célèbre serveur Flashback !

# Preview

 - 🎥 [Vidéo Preview HUD](https://streamable.com/477a6f)
 
 ![screenshot](https://media.discordapp.net/attachments/723268302255816724/862103945080995860/FlashbackHUD.PNG)
 
# Requirements

- [esx_basicneeds](https://discord.com/channels/723245101282885742/723274007889182752/838806258282004481) 
- [esx_status](https://discord.com/channels/723245101282885742/723274007889182752/838806286275313685) 


Si vous avez besoin d'aide pour l'installation : https://discord.gg/eX9GXWN 🌐

# Author 
Discord : WayZe#0001 | Youtube : WayZe | Twitter : @WayZeTV

### License
esx_cutomui Modification - Réalisé dans le style du serveur [Flashback](https://discord.gg/flashback)

Copyright (C) 2021 WayZe

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.
